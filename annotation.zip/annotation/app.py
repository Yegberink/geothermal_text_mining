# app.py
import os
import json
import zlib
from datetime import datetime

import pandas as pd
import streamlit as st
from sqlalchemy import create_engine, text

# --- Config ---
DATA_PATH = "sentences_for_annotation.csv"  # your updated path
DB_URL = os.environ.get("DB_URL", "sqlite:///annotations.db")
engine = create_engine(DB_URL, future=True)

SENTIMENTS = ["Positive", "Neutral", "Negative"]

ANNOTATORS = ["Egberink", "Dekker"]

# NEW: geothermal framing options (independent from sentiment!)
GEO_EFFECTS = [
    "Advantage",
    "Disadvantage",
    "Mixed",
    "Neutral/Info",
    "Not about geothermal",
    "Unclear",
]

# split/overlap settings
OVERLAP_MOD = 10          # 10% overlap
OVERLAP_BUCKET = 0        # bucket that both see


def stable_bucket(sentence_id) -> int:
    """
    Returns an integer bucket in [0, OVERLAP_MOD-1] deterministically.
    Works for numeric or string sentence_id.
    """
    s = str(sentence_id).encode("utf-8")
    return zlib.crc32(s) % OVERLAP_MOD


# --- DB setup ---
def init_db():
    with engine.begin() as conn:
        conn.execute(text("""
        CREATE TABLE IF NOT EXISTS tasks (
            sentence_id TEXT PRIMARY KEY,
            sentence_text TEXT NOT NULL,
            aspect_pred TEXT,
            sentiment_pred TEXT,
            split_bucket INTEGER NOT NULL,
            meta_json TEXT
        )"""))

        conn.execute(text("""
        CREATE TABLE IF NOT EXISTS categories (
            name TEXT PRIMARY KEY,
            created_by TEXT,
            created_at TEXT
        )"""))

        # NEW: geo_effect column
        conn.execute(text("""
        CREATE TABLE IF NOT EXISTS annotations (
            sentence_id TEXT,
            annotator TEXT,
            aspect_correct INTEGER,
            sentiment_correct INTEGER,
            category TEXT,
            geo_effect TEXT,
            aspect_true TEXT,
            sentiment_true TEXT,
            notes TEXT,
            created_at TEXT,
            PRIMARY KEY (sentence_id, annotator)
        )"""))


def ensure_geo_effect_column():
    """
    If the user already has an existing annotations.db created before geo_effect existed,
    this will add the column safely.
    """
    with engine.begin() as conn:
        cols = conn.execute(text("PRAGMA table_info(annotations)")).all()
        colnames = {c[1] for c in cols}  # c[1] is the column name
        if "geo_effect" not in colnames:
            conn.execute(text("ALTER TABLE annotations ADD COLUMN geo_effect TEXT"))


def seed_tasks_if_empty(df: pd.DataFrame):
    """
    Seeds tasks once. Requires df to include:
      - sentence_id
      - sentence_text
      - aspect (predicted)
      - sentiment (predicted)
    """
    required = {"sentence_id", "sentence_text", "aspect", "sentiment"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns in CSV: {sorted(missing)}")

    with engine.begin() as conn:
        n = conn.execute(text("SELECT COUNT(*) FROM tasks")).scalar_one()
        if n > 0:
            return

        df = df.copy()

        for _, r in df.iterrows():
            sid = r["sentence_id"]
            bucket = stable_bucket(sid)

            meta = {
                k: (None if pd.isna(r[k]) else r[k])
                for k in df.columns
                if k not in ["sentence_id", "sentence_text", "aspect", "sentiment"]
            }

            conn.execute(
                text("""
                    INSERT INTO tasks(sentence_id, sentence_text, aspect_pred, sentiment_pred, split_bucket, meta_json)
                    VALUES(:sentence_id, :sentence_text, :aspect_pred, :sentiment_pred, :split_bucket, :meta_json)
                """),
                dict(
                    sentence_id=str(sid),
                    sentence_text=str(r["sentence_text"]),
                    aspect_pred=None if pd.isna(r["aspect"]) else str(r["aspect"]),
                    sentiment_pred=None if pd.isna(r["sentiment"]) else str(r["sentiment"]),
                    split_bucket=int(bucket),
                    meta_json=json.dumps(meta, ensure_ascii=False),
                )
            )


def get_categories():
    with engine.begin() as conn:
        rows = conn.execute(text("SELECT name FROM categories ORDER BY name")).all()
    return [r[0] for r in rows]


def add_category(name: str, user: str):
    name = name.strip()
    if not name:
        return
    with engine.begin() as conn:
        conn.execute(
            text("""
                INSERT OR IGNORE INTO categories(name, created_by, created_at)
                VALUES(:name, :created_by, :created_at)
            """),
            dict(name=name, created_by=user, created_at=datetime.utcnow().isoformat()),
        )


def assignment_where_clause(user: str) -> str:
    """
    Returns an SQL fragment for which tasks the user should label.

    - overlap bucket (0) is visible to both
    - all other buckets split:
        Dekker -> even buckets (2,4,6,8)
        Egberink -> odd buckets (1,3,5,7,9)
    """
    if user not in ANNOTATORS:
        return "1=0"

    if user == "Dekker":
        return f"(t.split_bucket = {OVERLAP_BUCKET} OR (t.split_bucket % 2 = 0 AND t.split_bucket != {OVERLAP_BUCKET}))"
    else:  # Egberink
        return f"(t.split_bucket = {OVERLAP_BUCKET} OR (t.split_bucket % 2 = 1))"


def next_unlabeled_sentence_id(user: str):
    where_assign = assignment_where_clause(user)

    with engine.begin() as conn:
        row = conn.execute(
            text(f"""
                SELECT t.sentence_id
                FROM tasks t
                LEFT JOIN annotations a
                  ON a.sentence_id = t.sentence_id AND a.annotator = :user
                WHERE a.sentence_id IS NULL
                  AND {where_assign}
                ORDER BY t.sentence_id
                LIMIT 1
            """),
            dict(user=user)
        ).first()

    return None if row is None else row[0]


def load_task(sentence_id: str):
    with engine.begin() as conn:
        row = conn.execute(
            text("""
                SELECT sentence_id, sentence_text, aspect_pred, sentiment_pred, meta_json, split_bucket
                FROM tasks
                WHERE sentence_id = :sentence_id
            """),
            dict(sentence_id=str(sentence_id))
        ).first()
    return row


def save_annotation(sentence_id: str, user: str, aspect_ok: bool, sent_ok: bool,
                    category: str, geo_effect: str, aspect_true: str, sent_true: str, notes: str):
    with engine.begin() as conn:
        conn.execute(text("""
            INSERT OR REPLACE INTO annotations
            (sentence_id, annotator, aspect_correct, sentiment_correct, category,
             geo_effect, aspect_true, sentiment_true, notes, created_at)
            VALUES
            (:sentence_id, :annotator, :aspect_correct, :sentiment_correct, :category,
             :geo_effect, :aspect_true, :sentiment_true, :notes, :created_at)
        """), dict(
            sentence_id=str(sentence_id),
            annotator=user,
            aspect_correct=1 if aspect_ok else 0,
            sentiment_correct=1 if sent_ok else 0,
            category=category,
            geo_effect=geo_effect,
            aspect_true=aspect_true or None,
            sentiment_true=sent_true or None,
            notes=notes or None,
            created_at=datetime.utcnow().isoformat(),
        ))


# --- App ---
st.set_page_config(page_title="Geothermal SA/Aspect Review", layout="wide")
st.title("Review tool: aspect + sentiment + geothermal framing + topic coding")

init_db()
ensure_geo_effect_column()

df = pd.read_csv(DATA_PATH)
seed_tasks_if_empty(df)

# Top bar
top_left, top_right = st.columns([2, 1], gap="large")
with top_left:
    st.caption(
        f"Assignment: ~{100//OVERLAP_MOD}% overlap (bucket {OVERLAP_BUCKET}); remaining items split between annotators."
    )
with top_right:
    user = st.selectbox("Annotator", ANNOTATORS)

# Shared category choices
cats = get_categories()
base_choices = cats + ["Other (add new)"]

# Find next task
if "sentence_id" not in st.session_state:
    st.session_state.sentence_id = next_unlabeled_sentence_id(user)

sentence_id = st.session_state.sentence_id
if sentence_id is None:
    st.success("You’re done — no remaining sentences assigned to you.")
    st.stop()

row = load_task(sentence_id)
sid, sentence_text, aspect_pred, sentiment_pred, meta_json, split_bucket = row

# Two-column main layout
left, right = st.columns([3, 2], gap="large")

with left:
    st.subheader(f"Sentence ID: {sid}")
    st.write(sentence_text)

    st.markdown("### Model output")
    st.markdown(f"- **Aspect (pred):** {aspect_pred}")
    st.markdown(f"- **Sentiment (pred):** {sentiment_pred}")
    st.markdown(
        f"- **Split bucket:** {split_bucket} " + ("(overlap)" if split_bucket == OVERLAP_BUCKET else "")
    )

    with st.expander("Metadata (optional)", expanded=False):
        meta = json.loads(meta_json) if meta_json else {}
        if meta:
            st.json(meta)
        else:
            st.caption("No metadata stored for this sentence.")

with right:
    st.subheader("Your evaluation")

    aspect_ok = st.checkbox("Aspect is correct", value=True)
    sent_ok = st.checkbox("Sentiment is correct", value=True)

    geo_effect = st.radio(
        "Geothermal framing",
        GEO_EFFECTS,
        index=0,
        help="Independent from sentiment: does this sentence frame geothermal as an advantage/disadvantage?"
    )

    # Follow-up fields only if needed
    aspect_true = ""
    if not aspect_ok:
        aspect_true = st.text_input("Correct aspect (optional)", value="")

    sent_true = ""
    if not sent_ok:
        sent_true = st.radio("Correct sentiment (optional)", SENTIMENTS, index=1, horizontal=True)

    # Topic coding only when advantage/disadvantage is actually present
    needs_topic = geo_effect in ["Advantage", "Disadvantage", "Mixed"]
    category = None

    if needs_topic:
        st.markdown("### Issue/Advantage topic")
        st.caption("Pick the main issue or benefit being discussed (one best label).")

        category = st.selectbox("Topic", base_choices)

        if category == "Other (add new)":
            new_cat = st.text_input("New topic label", placeholder="e.g., groundwater pollution")
            if new_cat.strip():
                add_category(new_cat, user)
                category = new_cat.strip()
    else:
        st.markdown("### Issue/Advantage topic")
        st.caption("Skipped because this sentence is not an advantage/disadvantage statement.")

    notes = st.text_area("Notes (optional)", height=90)

    # Buttons at bottom-right
    b1, b2 = st.columns(2)
    with b1:
        if st.button("Save", use_container_width=True):
            if geo_effect not in ["Advantage", "Disadvantage", "Mixed"]:
                category = None
            save_annotation(sid, user, aspect_ok, sent_ok, category, geo_effect, aspect_true, sent_true, notes)
            st.success("Saved.")
    with b2:
        if st.button("Save & Next ➜", use_container_width=True):
            if geo_effect not in ["Advantage", "Disadvantage", "Mixed"]:
                category = None
            save_annotation(sid, user, aspect_ok, sent_ok, category, geo_effect, aspect_true, sent_true, notes)
            st.session_state.sentence_id = next_unlabeled_sentence_id(user)
            st.rerun()